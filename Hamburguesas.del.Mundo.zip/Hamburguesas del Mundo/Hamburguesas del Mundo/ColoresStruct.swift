//
//  ColoresStruct.swift
//  Hamburguesas del Mundo
//
//  Created by James Montoya on 29/02/16.
//  Copyright (c) 2016 James Montoya. All rights reserved.
//

import Foundation
import UIkit

struct Colores {
    let colores = [UIColor(red: 12/100, green: 30/100, blue: 234/100, alpha: 1),
        UIColor(red: 189/100, green: 30/100, blue: 23/100, alpha: 1),
        UIColor(red: 12/100, green: 30/100, blue: 34/100, alpha: 1),
        UIColor(red: 12/100, green: 198/100, blue: 50/100, alpha: 1),
        UIColor(red: 98/100, green: 179/100, blue: 23/100, alpha: 1),
        UIColor(red: 12/100, green: 65/100, blue: 10/100, alpha: 1)]
    
    
    func regresaColorAleatorio()-> UIColor {
        let posicion = Int(arc4random()) % colores.count
        return colores[posicion]
    }
}
