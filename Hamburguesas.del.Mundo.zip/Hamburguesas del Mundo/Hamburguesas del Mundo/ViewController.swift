//
//  ViewController.swift
//  Hamburguesas del Mundo
//
//  Created by James Montoya on 29/02/16.
//  Copyright (c) 2016 James Montoya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var paisSeleccionado: UILabel!
    
    @IBOutlet weak var hamburguesaSeleccionada: UILabel!
    
    var paises = ColeccionDePaises()
    var hamburguesas = ColeccionDeHamburguesa()
    var colores = Colores ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func siguienteHamburguesa(){
        let pais = paises.obtenPais()
        let hamburguesa = hamburguesas.obtenHamburguesa()
        
        
        paisSeleccionado.text = pais
        hamburguesaSeleccionada.text = hamburguesa
        
        let colorAleatorio = colores.regresaColorAleatorio()
        view.backgroundColor = colorAleatorio
        view.tintColor = colores.regresaColorAleatorio()
        
    }



}

